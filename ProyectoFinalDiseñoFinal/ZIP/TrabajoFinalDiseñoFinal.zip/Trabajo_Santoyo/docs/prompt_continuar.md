# Prompt para continuar EntreHoras UNAB en otro chat

Copia y pega este bloque en el siguiente chat para mantener continuidad exacta:

```text
Estoy continuando un proyecto llamado EntreHoras UNAB.

Ruta local del proyecto:
/Users/camilocalderon/Downloads/prueba

Antes de proponer o editar cualquier cosa, lee estos archivos:
- CONTEXTO_PROYECTO_ENTREHORAS.md
- index.html
- styles.css
- script.js

Es una SPA estatica para un proyecto de segundo semestre de Ingenieria de Sistemas en la UNAB. Debe mantenerse en HTML, CSS y JavaScript vanilla. No uses React, Vue, Next, backend, bundlers ni dependencias nuevas. El objetivo es que se vea bien, funcione y sea entendible para un estudiante.

Estado actual esperado:
- index.html: 506 lineas
- styles.css: 1155 lineas
- script.js: 962 lineas
- CONTEXTO_PROYECTO_ENTREHORAS.md: 365 lineas

Hashes SHA-256 del estado al cerrar el chat anterior:
- index.html: f1eaaa81d740c4b1a06dc47f1fe7a69c9af5ae35e3e9f98bc9be2d8ff4de64a2
- styles.css: eceba35d9aef5da5b6e6287e1f358aa192d36308c23666dc975549b622919e28
- script.js: 6f8d2d9a3d8e3996ff85741116f540d19ab2745335b43f27c57b667359082dc5
- CONTEXTO_PROYECTO_ENTREHORAS.md: 9ebef7e20d4b0523c572e0c7b514dc34913d565b7c14cfaf1e3d167b13e58707

Comandos utiles para validar que sigues en el mismo estado:
shasum -a 256 index.html styles.css script.js CONTEXTO_PROYECTO_ENTREHORAS.md
wc -l index.html styles.css script.js CONTEXTO_PROYECTO_ENTREHORAS.md
node --check script.js

Contexto funcional importante:
- La app inicia en vista-login.
- showVista(id, guardarHistorial = true) controla las vistas.
- Hay historial simple de vistas con volverVista(fallback).
- body usa auth-mode para login/registro y dashboard-mode para vistas internas.
- El logo oficial UNAB se carga desde:
  https://pasaporte.unab.edu.co/upload/surveys/993455/images/LOGO%20UNAB-MINEDUCACION_v%20-%204.png
- El fondo UNAB se carga desde:
  https://unired.edu.co/images/instituciones/UNAB/2017/junio/unab.jpg
- El codigo estudiantil valido es U + 8 digitos, ejemplo U00182939.
- STATE.favoritos guarda ids numericos de LUGARES, no nombres.
- renderFavoriteButton(lugarId), isFavorito(lugarId) y toggleFavorito(lugarId) manejan favoritos.
- Mis HL usa renderRegistroCard() para cards con imagen.
- getLugarByRegistro() intenta emparejar una reserva con LUGARES para sacar imagen.
- Perfil tiene modal editable y tabla responsive con .historial-table-wrap.
- Horario mensual usa fechaISO en STATE.registros.

Prioridades si sigues mejorando:
1. Primero prueba visualmente login, registro, lugares, favoritos, mis HL, perfil y horario.
2. Si algo falla, arregla el bug puntual antes de redisenar.
3. Mantén el codigo simple y legible.
4. Evita duplicacion nueva; si creas helpers, que sean pequenos y faciles.
5. No elimines funcionalidades que ya funcionan.
6. Antes de terminar, corre node --check script.js.

Advertencias:
- Playwright CLI existe, pero la cache local no tiene navegador instalado. Si quieres screenshots automatizados, primero habria que instalar browsers con npx playwright install.
- No hay git repo en esta carpeta, asi que git diff no sirve salvo que se inicialice repo o se use --no-index.
- El estado no persiste al recargar porque no hay backend ni localStorage.

Solicitud de estilo:
El usuario quiere una app bonita pero normal para proyecto universitario, no algo sobreingenierizado. Evita codigo espaguetti, pero tambien evita soluciones demasiado profesionales que parezcan fuera de nivel del curso.
```

## Mini resumen para pegar si no quieres pegar todo

```text
Continua EntreHoras UNAB en /Users/camilocalderon/Downloads/prueba. Lee CONTEXTO_PROYECTO_ENTREHORAS.md y los 3 archivos principales antes de tocar nada. Es SPA estatica HTML/CSS/JS vanilla para segundo semestre. No frameworks, no backend, no bundlers. Mantener showVista() como navegacion. Favoritos usan ids. Login/registro usan logo y fondo UNAB remotos. Mis HL ya tiene cards visuales. Perfil tiene modal responsive. Corre node --check script.js antes de terminar.
```
