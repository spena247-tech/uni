# Contexto completo del proyecto - EntreHoras UNAB

## Resumen del proyecto

EntreHoras UNAB es una SPA estatica hecha con HTML, CSS y JavaScript vanilla para un proyecto de segundo semestre de Ingenieria de Sistemas en la UNAB. La idea es que estudiantes puedan iniciar sesion, registrar una cuenta, ver un dashboard, consultar lugares del campus, reservar espacios para horas libres, revisar sus reservas en "Mis HL", marcar favoritos, ver un horario mensual y editar su perfil.

El proyecto debe mantenerse simple y entendible para un curso basico: sin frameworks, sin backend, sin bundlers, sin librerias externas de JS. Todo vive en estos archivos:

- `index.html`
- `styles.css`
- `script.js`

Hay un archivo de plan anterior, `CLAUDE (2).md`, pero el estado real del proyecto ya avanzo bastante mas que ese plan.

## Estado actual de la app

La app ya tiene estas vistas:

- `vista-login`: vista inicial actual.
- `vista-registro`: formulario de registro.
- `vista-dashboard`: inicio del dashboard.
- `vista-lugares`: exploracion de lugares.
- `vista-detalle-lugar`: detalle de un lugar.
- `vista-registro-exitoso`: confirmacion despues de reservar.
- `vista-mis-hl`: reservas activas e historial.
- `vista-favoritos`: lugares favoritos.
- `vista-perfil`: perfil del estudiante.
- `vista-horario`: calendario mensual de reservas.

La navegacion principal se maneja con `showVista(id)` en `script.js`. No hay rutas reales ni backend; se muestran y ocultan `<section class="vista">`.

## Decisiones importantes ya tomadas

- La app inicia en login, no en registro.
- El codigo estudiantil valido es `U` + 8 digitos, ejemplo `U00182939`.
- Los datos de registro actualizan `STATE.usuario`.
- El logout existe en el header del dashboard y vuelve al login.
- El estado de la app vive en memoria dentro de `STATE`.
- Los favoritos se guardan por `id` de lugar, no por nombre.
- Se usa logo oficial remoto de la UNAB:
  `https://pasaporte.unab.edu.co/upload/surveys/993455/images/LOGO%20UNAB-MINEDUCACION_v%20-%204.png`
- Se usa fondo remoto de la UNAB:
  `https://unired.edu.co/images/instituciones/UNAB/2017/junio/unab.jpg`
- No se agrego persistencia real; al recargar se reinicia el estado.
- El estilo debe verse mejor, pero seguir siendo razonablemente simple para HTML/CSS/JS basico.

## Cambios implementados recientemente

### Autenticacion y registro

- `index.html` ahora tiene `vista-login` como la unica vista activa inicial.
- El input de codigo en registro usa `maxlength="9"` y placeholder `U00182939`.
- `handleRegistro()` valida con regex `^U\d{8}$`.
- Al crear cuenta se guardan en `STATE.usuario`:
  - nombre
  - codigo
  - correo
  - programa
- `handleLogin()` sigue siendo demo: valida que correo y password no esten vacios y entra al dashboard.
- `logout()` cierra modales si existen, muestra toast y vuelve a `vista-login`.

### Logo y fondos

- Header y login usan imagen oficial del logo UNAB mediante clase `.logo-img` / `.login-logo-img`.
- `body.auth-mode` aplica fondo fotografico UNAB al login/registro.
- El panel izquierdo del registro usa `.panel-left-photo` con la misma foto.
- El SVG decorativo de edificios sigue en el HTML, pero queda oculto por CSS cuando esta `.panel-left-photo`.

### Navegacion

- `showVista(id, guardarHistorial = true)` es el centro de navegacion.
- Se agregaron:
  - `vistaActual`
  - `historialVistas`
  - `getVistaActiva()`
  - `volverVista(fallback)`
- El boton "Volver a Lugares" en detalle usa `volverVista('vista-lugares')`.
- `showVista()` alterna clases en body:
  - `dashboard-mode` para vistas internas.
  - `auth-mode` para login/registro.
- `setNavActivo()` marca correctamente sidebar y bottom nav para:
  - Inicio
  - Mis HL
  - Lugares
  - Favoritos
  - Perfil
  - Horario
- `vista-detalle-lugar` cuenta como contexto de Lugares.
- `vista-registro-exitoso` cuenta como contexto de Mis HL.

### Favoritos

- `STATE.favoritos` ahora es un array de ids, por ejemplo `[6, 1]`.
- Helpers relevantes:
  - `isFavorito(lugarId)`
  - `renderFavoriteButton(lugarId)`
  - `toggleFavorito(lugarId)`
- El boton de favoritos aparece en:
  - cada card de `Lugares`
  - el hero de `Detalle Lugar`
  - cada card de `Favoritos`
- `renderFavoritos()` filtra con `LUGARES.filter(l => favs.includes(l.id))`.

### Mis HL

- La vista `Mis HL` conserva tabs:
  - Activos
  - Historial
- Se redisenaron las cards de reservas con imagen.
- Helper relevante:
  - `getLugarByRegistro(registro)`: busca imagen por `lugarId` o por coincidencia de nombre.
  - `renderRegistroCard(registro, idx, puedeCancelar)`: renderiza la card visual.
- Si no encuentra lugar, usa `CONFIG.fondoUnabUrl` como imagen de respaldo.
- Cancelar registro sigue usando `cancelarRegistro(idx)`.

### Horario

- Existe `vista-horario`.
- Botones `Ver Horario` se enlazan con `bindStaticControls()`.
- `renderHorario()` muestra calendario mensual del mes actual.
- Las reservas activas con `fechaISO` se marcan en el calendario.
- Seleccionar un dia llama `seleccionarDiaHorario(iso)`.
- Cuando se confirma una reserva en `confirmarRegistro()`, se guarda:
  - `lugarId`
  - `fecha`
  - `fechaISO`
  - `hora`
  - `estado: 'activo'`

### Perfil

- `renderPerfil()` muestra:
  - nombre
  - codigo
  - correo
  - programa
  - semestre
  - resumen HL
  - tabla de historial
- "Editar perfil" abre modal funcional.
- Funciones:
  - `abrirPerfilModal()`
  - `cerrarPerfilModal()`
  - `guardarPerfil()`
- Validaciones:
  - nombre no vacio
  - codigo `U` + 8 digitos
  - correo no vacio
  - programa seleccionado
  - semestre no vacio
- CSS responsive:
  - `.perfil-fila-valor` usa `overflow-wrap:anywhere`.
  - tabla envuelta en `.historial-table-wrap` con scroll horizontal.
  - modal con `max-height: 88vh` y `overflow-y:auto`.

## Estructura de datos importante

### `CONFIG`

Contiene:

- `universidadNombre`
- `dominioCorreo`
- `logoUrl`
- `fondoUnabUrl`
- `programasAcademicos`

### `STATE`

Contiene:

- `usuario`
- `lugarActual`
- `diaHorarioSeleccionado`
- `registros`
- `historialHL`
- `favoritos`
- `noticias`

### `LUGARES`

Array de lugares del campus. Cada lugar tiene:

- `id`
- `nombre`
- `tipo`
- `categoria`
- `disponible`
- `capacidad`
- `ocupados`
- `horario`
- `desc`
- `ubicacion`
- `img`

## Funciones clave en `script.js`

Navegacion:

- `showVista(id, guardarHistorial = true)`
- `volverVista(fallback = 'vista-dashboard')`
- `isDashboardVista(id)`
- `setHeaderDefault()`
- `setHeaderDashboard()`
- `setNavActivo(vistaId)`

Auth:

- `handleRegistro()`
- `handleLogin()`
- `logout()`

UI/helpers:

- `logoMarkup(targetVista)`
- `showToast(msg, tipo)`
- `setError(wrapId, errId, show)`
- `clearErrors(ids)`
- `togglePw(inputId, btn)`
- `bindStaticControls()`

Lugares/favoritos:

- `filtrarLugares()`
- `setFiltro(cat)`
- `renderLugares()`
- `verDetalleLugar(id)`
- `renderDetalleLugar()`
- `toggleFavorito(lugarId)`
- `renderFavoritos()`
- `renderFavoriteButton(lugarId)`
- `isFavorito(lugarId)`

Reservas/Mis HL/Horario:

- `abrirModal()`
- `cerrarModal()`
- `confirmarRegistro()`
- `renderRegistroExitoso()`
- `renderMisHL()`
- `renderRegistroCard(registro, idx, puedeCancelar)`
- `cancelarRegistro(idx)`
- `renderHorario()`
- `seleccionarDiaHorario(iso)`

Perfil:

- `renderPerfil()`
- `abrirPerfilModal()`
- `cerrarPerfilModal()`
- `guardarPerfil()`

## CSS relevante

Base:

- Variables en `:root`.
- `.vista` y `.vista.activa` controlan pantallas.
- `.dashboard-layout` define sidebar + contenido.
- `.bottom-nav` aparece en mobile dentro de `body.dashboard-mode`.

Logo/fondos:

- `body.auth-mode`
- `.logo-img`
- `.login-logo-img`
- `.panel-left-photo`
- `.panel-left-photo .city-placeholder`

Favoritos:

- `.btn-favorito`
- `.btn-favorito.activo`
- `.btn-fav-detalle`

Mis HL:

- `.registros-grid`
- `.registro-card-visual`
- `.registro-img-wrap`
- `.registro-img`
- `.registro-body`

Perfil responsive:

- `.perfil-fila-valor`
- `.historial-table-wrap`
- `.modal-card`
- media queries `max-width: 860px` y `max-width: 600px`

## Verificacion ya hecha

Se corrio:

```bash
node --check script.js
```

Resultado: pasa sin errores.

Tambien se levanto un servidor local:

```bash
python3 -m http.server 8787
curl -I http://127.0.0.1:8787/index.html
```

Resultado: `HTTP/1.0 200 OK`.

Se intento usar Playwright para captura, pero faltan los browsers instalados en la cache local. Error esperado:

```text
Executable doesn't exist ...
Please run: npx playwright install
```

No se dejo ningun servidor corriendo.

## Pendientes recomendados para siguiente chat

1. Hacer una prueba visual manual abriendo `index.html` o con servidor local.
2. Revisar si el logo oficial remoto carga bien y no se ve muy pequeno en header.
3. Revisar si el fondo del login se ve bien en pantalla pequena.
4. Validar que favoritos:
   - se marquen desde Lugares
   - aparezcan en Favoritos
   - se quiten desde Favoritos
   - se actualicen en Detalle
5. Validar que Mis HL se vea mejor y no se rompa en mobile.
6. Revisar si el bottom nav con 6 items se siente apretado en celulares pequenos.
7. Posible mejora futura: unificar sidebars repetidos en HTML para reducir duplicacion, pero hacerlo con cuidado porque el proyecto debe seguir siendo facil de entender.

## Instrucciones para continuar en otro chat

Puedes pegar este resumen y decir:

```text
Estoy trabajando en una SPA estatica llamada EntreHoras UNAB en /Users/camilocalderon/Downloads/prueba.
Lee CONTEXTO_PROYECTO_ENTREHORAS.md, index.html, styles.css y script.js.
Continua desde el estado actual, manteniendo HTML/CSS/JS basico sin frameworks.
Primero revisa el codigo real antes de proponer o editar.
```

## Principios que debe seguir el siguiente agente

- No convertir esto en React/Vue/Next.
- No agregar backend.
- No meter abstracciones complicadas.
- Mantener `showVista()` como sistema principal de navegacion.
- Evitar codigo espaguetti, pero sin sobreingenieria.
- Preferir helpers pequenos y claros.
- Cada cambio visual debe conservar funcionalidad.
- Antes de terminar, correr al menos:

```bash
node --check script.js
```

Y si es posible:

```bash
python3 -m http.server 8787
```

Luego abrir `http://127.0.0.1:8787/index.html`.
