# CLAUDE.md — EntreHoras UNAB
## Contexto completo del proyecto para OpenCode

---

## 1. DESCRIPCIÓN DEL PROYECTO

**EntreHoras UNAB** es una SPA (Single Page Application) web para estudiantes de la Universidad Autónoma de Bucaramanga (UNAB). Permite gestionar las **Horas Libres (HL)**, explorar espacios del campus, registrarse en lugares y hacer seguimiento del progreso académico.

- **Stack**: HTML5 + CSS3 + JavaScript vanilla (sin frameworks, sin backend)
- **Arquitectura**: SPA con sistema de vistas (`.vista` / `.vista.activa`)
- **Archivos**: `index.html`, `styles.css`, `script.js`
- **Todo debe estar en esos 3 archivos**. No usar módulos externos ni bundlers.

---

## 2. ESTADO ACTUAL DEL CÓDIGO

### ✅ YA EXISTE Y FUNCIONA:
- `index.html`: Vista de **Registro** (completa) + Vista de **Login** (completa) + placeholder de Dashboard vacío
- `styles.css`: Sistema completo de variables CSS, card layout, formularios, inputs, botones, toast, responsive
- `script.js`: Navegación entre vistas (`showVista()`), validación de formularios, toggle contraseña, toast

### ❌ FALTA CONSTRUIR (prioridad):
Todas las vistas del dashboard: **Inicio, Mis HL, Lugares, Detalle Lugar, Registro Exitoso, Favoritos, Perfil**

---

## 3. SISTEMA DE NAVEGACIÓN

La SPA usa este patrón — **NO cambiar esta lógica**:

```javascript
function showVista(id) {
  document.querySelectorAll('.vista').forEach(v => v.classList.remove('activa'));
  document.getElementById(id).classList.add('activa');
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
```

Cada pantalla es un `<section class="vista" id="vista-NOMBRE">`. Solo la activa tiene `display:flex`.

### IDs de vistas requeridas:
| ID | Pantalla |
|---|---|
| `vista-registro` | ✅ Existe |
| `vista-login` | ✅ Existe |
| `vista-dashboard` | ⚠️ Existe pero vacío — REEMPLAZAR |
| `vista-lugares` | ❌ Crear |
| `vista-detalle-lugar` | ❌ Crear |
| `vista-registro-exitoso` | ❌ Crear |
| `vista-mis-hl` | ❌ Crear |
| `vista-favoritos` | ❌ Crear |
| `vista-perfil` | ❌ Crear |

---

## 4. SISTEMA DE DISEÑO — TOKENS EXACTOS

### Variables CSS (ya definidas en styles.css — NO modificar):
```css
:root {
  --color-header:       #0ea5c8;   /* Azul cyan — header y acentos */
  --color-header-dark:  #0891b2;   /* Cyan oscuro — hover links */
  --color-boton:        #f59e0b;   /* Naranja/ámbar — botón primario */
  --color-boton-hover:  #d97706;   /* Naranja hover */
  --color-panel-left:   #1e3a5f;   /* Azul marino — panel izquierdo registro */
  --color-acento:       #0ea5c8;   /* Cyan — links, progress, títulos dashboard */
  --color-texto:        #1e293b;   /* Gris oscuro — texto principal */
  --color-sublabel:     #64748b;   /* Gris medio — subtítulos, labels */
  --color-borde:        #e2e8f0;   /* Gris claro — bordes */
  --color-fondo:        #f1f5f9;   /* Gris muy claro — fondo general */
  --color-error:        #ef4444;   /* Rojo — errores */
  --color-exito:        #22c55e;   /* Verde — éxito */
  --radio:              5px;
  --sombra:             0 20px 60px rgba(0,0,0,.12);
  --font-main:          'DM Sans', sans-serif;
}
```

### Colores adicionales para el dashboard:
```css
/* Estado disponible */
--color-disponible: #22c55e;     /* Verde */
/* Estado lleno/ocupado */
--color-lleno: #ef4444;          /* Rojo */
/* Progress ring */
--color-progress: #f59e0b;       /* Naranja ámbar */
/* Sidebar activo */
--color-sidebar-activo: #0ea5c8; /* Cyan */
```

### Tipografía:
- **Font**: `'DM Sans', sans-serif` (ya cargada desde Google Fonts)
- Títulos dashboard: `font-size: 1.6–2rem`, `font-weight: 700`, `color: var(--color-acento)`
- Subtítulos: `font-size: .92rem`, `color: var(--color-sublabel)`
- Labels tabla: `font-size: .72rem`, `font-weight: 600`, uppercase, letter-spacing

---

## 5. LAYOUT DEL DASHBOARD (todas las vistas post-login)

El dashboard tiene un layout de **sidebar izquierdo + contenido derecho**:

```
┌─────────────────────────────────────────────┐
│              HEADER (sticky, cyan)          │
├──────────────┬──────────────────────────────┤
│              │                              │
│   SIDEBAR    │      CONTENIDO PRINCIPAL     │
│   (240px)    │      (flex: 1)               │
│              │                              │
│  - Avatar    │                              │
│  - Nombre    │                              │
│  - Ver Hor.  │                              │
│  ─────────   │                              │
│  - Inicio    │                              │
│  - Mis HL    │                              │
│  - Lugares   │                              │
│  - Favoritos │                              │
│  - Perfil    │                              │
└──────────────┴──────────────────────────────┘
│                   FOOTER                    │
```

### HTML del layout dashboard (usar como base para cada vista):
```html
<section class="vista" id="vista-NOMBRE">
  <div class="dashboard-layout">
    <!-- SIDEBAR -->
    <aside class="sidebar">
      <div class="sidebar-profile">
        <div class="sidebar-avatar">
          <svg><!-- icono usuario --></svg>
        </div>
        <span class="sidebar-nombre">Camilo Gómez</span>
        <span class="sidebar-rol">UNAB Student</span>
      </div>
      <button class="btn-ver-horario" onclick="/* futuro */">Ver Horario</button>
      <nav class="sidebar-nav">
        <a class="nav-item" onclick="showVista('vista-dashboard')">
          <!-- icono home --> Inicio
        </a>
        <a class="nav-item" onclick="showVista('vista-mis-hl')">
          <!-- icono reloj --> Mis HL
        </a>
        <a class="nav-item" onclick="showVista('vista-lugares')">
          <!-- icono pin --> Lugares
        </a>
        <a class="nav-item" onclick="showVista('vista-favoritos')">
          <!-- icono corazón --> Favoritos
        </a>
        <a class="nav-item" onclick="showVista('vista-perfil')">
          <!-- icono persona --> Perfil
        </a>
      </nav>
    </aside>
    <!-- CONTENIDO -->
    <main class="dash-content">
      <!-- Contenido específico de cada vista -->
    </main>
  </div>
</section>
```

### CSS del layout dashboard (agregar a styles.css):
```css
.dashboard-layout {
  display: grid;
  grid-template-columns: 240px 1fr;
  min-height: calc(100vh - 56px - 61px); /* 56=header, 61=footer */
  width: 100%;
  max-width: 1200px;
  background: #fff;
  border-radius: 8px;
  box-shadow: var(--sombra);
  overflow: hidden;
}

.sidebar {
  background: #fff;
  border-right: 1px solid var(--color-borde);
  padding: 28px 20px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.sidebar-profile { text-align: center; padding-bottom: 16px; border-bottom: 1px solid var(--color-borde); }
.sidebar-avatar {
  width: 72px; height: 72px; border-radius: 50%;
  background: var(--color-fondo); margin: 0 auto 10px;
  display: flex; align-items: center; justify-content: center;
  border: 2px solid var(--color-borde);
}
.sidebar-nombre { display: block; font-weight: 700; color: var(--color-acento); font-size: .95rem; }
.sidebar-rol { display: block; font-size: .78rem; color: var(--color-sublabel); }

.btn-ver-horario {
  display: block; width: 100%; padding: 10px;
  background: var(--color-boton); color: #fff;
  font-family: var(--font-main); font-weight: 600; font-size: .85rem;
  border: none; border-radius: var(--radio); cursor: pointer;
  margin: 8px 0; transition: background .2s;
}
.btn-ver-horario:hover { background: var(--color-boton-hover); }

.sidebar-nav { display: flex; flex-direction: column; gap: 4px; margin-top: 8px; }
.nav-item {
  display: flex; align-items: center; gap: 10px;
  padding: 10px 14px; border-radius: var(--radio);
  cursor: pointer; font-size: .88rem; color: var(--color-texto);
  text-decoration: none; transition: background .15s, color .15s;
}
.nav-item:hover { background: var(--color-fondo); color: var(--color-acento); }
.nav-item.activo { background: rgba(14,165,200,.1); color: var(--color-acento); font-weight: 600; border-left: 3px solid var(--color-acento); }
.nav-item svg { width: 18px; height: 18px; flex-shrink: 0; }

.dash-content { padding: 40px 40px; background: var(--color-fondo); overflow-y: auto; }
```

---

## 6. ESTADO GLOBAL (JavaScript)

Usar un objeto `STATE` en `script.js` para simular datos del usuario. **No usar localStorage**.

```javascript
const STATE = {
  usuario: {
    nombre: 'Camilo Gómez',
    codigo: 'U0001234',
    programa: 'Ingeniería de Sistemas',
    semestre: '7mo',
    correo: 'camilo.gomez',
    hlCompletadas: 74,
    hlTotal: 120,
    hlPendientes: 46
  },
  lugarActual: null,      // objeto lugar seleccionado para vista-detalle
  registros: [            // registros activos del usuario
    { tipo: 'ESTUDIO INDIVIDUAL', nombre: 'Cubículo 4 - Biblioteca Central', fecha: '15 Nov 2023', hora: '14:00 - 16:00', estado: 'activo' },
    { tipo: 'TRABAJO GRUPAL', nombre: 'Sala C - Edificio L', fecha: '16 Nov 2023', hora: '08:00 - 10:00', estado: 'activo' },
    { tipo: 'LABORATORIO', nombre: 'Lab. Sistemas 2', fecha: '10 Nov 2023', hora: '10:00 - 12:00', estado: 'completado' }
  ],
  historialHL: [
    { fecha: '15 Oct 2023', lugar: 'Biblioteca Central', actividad: 'Estudio Independiente', horas: 4 },
    { fecha: '10 Oct 2023', lugar: 'Auditorio Mayor', actividad: 'Conferencia Tecnológica', horas: 2 },
    { fecha: '28 Sep 2023', lugar: 'Laboratorio de Redes', actividad: 'Práctica Libre', horas: 3 },
    { fecha: '15 Sep 2023', lugar: 'Cancha Múltiple', actividad: 'Torneo Interfacultades', horas: 5 }
  ],
  favoritos: ['Biblioteca Central - Piso 2', 'Sala de Estudio L-304', 'Cafetería Central - Terraza'],
  noticias: [
    { categoria: 'Evento Institucional', titulo: 'Feria de Organizaciones Estudiantiles 2024', desc: 'Descubre nuevas oportunidades para sumar horas libres participando en los...', tiempo: 'Hoy, 10:00 AM', img: 'https://images.unsplash.com/photo-1523580494863-6f3031224c94?w=400&q=80' },
    { categoria: 'Académico', titulo: 'Nuevos Espacios de Estudio Habilitados', desc: 'Se han habilitado 5 nuevas salas de estudio colaborativo en el Edificio K...', tiempo: 'Ayer', img: 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=400&q=80' },
    { categoria: 'Servicios', titulo: 'Horario Extendido en Biblioteca', desc: 'Durante la semana de parciales, la biblioteca principal operará 24/7 para...', tiempo: 'Hace 2 días', img: 'https://images.unsplash.com/photo-1521587760476-6c12a4b040da?w=400&q=80' }
  ]
};

const LUGARES = [
  { id: 1, nombre: 'Banú', tipo: 'ESTUDIO', categoria: 'Estudio', disponible: true, capacidad: 50, ocupados: 18, horario: '7:00 AM - 9:00 PM', desc: 'Espacio de trabajo colaborativo e individual equipado con conexiones eléctricas y red Wi-Fi de alta velocidad.', ubicacion: 'Edificio Central, Piso 3', img: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=600&q=80' },
  { id: 2, nombre: 'Gimnasio', tipo: 'DEPORTE', categoria: 'Deporte', disponible: false, capacidad: 60, ocupados: 60, horario: '6:00 AM - 10:00 PM', desc: 'Instalaciones deportivas de primer nivel para entrenamiento cardiovascular y de fuerza con acompañamiento profesional.', ubicacion: 'Edificio Deportivo, Planta Baja', img: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=600&q=80' },
  { id: 3, nombre: 'Cafetería Casona', tipo: 'ALIMENTACIÓN', categoria: 'Alimentación', disponible: true, capacidad: 80, ocupados: 32, horario: '7:00 AM - 6:00 PM', desc: 'Ambiente tradicional y acogedor, ideal para disfrutar de almuerzos completos y reuniones casuales entre clases.', ubicacion: 'Edificio Casona, Planta Baja', img: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=600&q=80' },
  { id: 4, nombre: 'Cafetería Bosque', tipo: 'ALIMENTACIÓN', categoria: 'Alimentación', disponible: true, capacidad: 45, ocupados: 15, horario: '7:30 AM - 5:30 PM', desc: 'Conexión con la naturaleza mientras disfrutas de snacks saludables, café de origen y opciones vegetarianas.', ubicacion: 'Zona Verde, Campus Principal', img: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=600&q=80' },
  { id: 5, nombre: 'Cafetería CSU', tipo: 'ALIMENTACIÓN', categoria: 'Alimentación', disponible: false, capacidad: 120, ocupados: 120, horario: '7:00 AM - 7:00 PM', desc: 'El centro gastronómico principal con múltiples opciones de comida rápida, menús del día y espacios amplios.', ubicacion: 'Edificio CSU, Primer Piso', img: 'https://images.unsplash.com/photo-1567521464027-f127ff144326?w=600&q=80' },
  { id: 6, nombre: 'Biblioteca Central', tipo: 'ESTUDIO', categoria: 'Estudio', disponible: true, capacidad: 200, ocupados: 87, horario: '7:00 AM - 10:00 PM', desc: 'La principal biblioteca del campus con acceso a bases de datos académicas, salas de lectura y zonas de silencio absoluto.', ubicacion: 'Edificio Biblioteca, todos los pisos', img: 'https://images.unsplash.com/photo-1521587760476-6c12a4b040da?w=600&q=80' },
  { id: 7, nombre: 'Auditorio Mayor', tipo: 'CULTURA', categoria: 'Cultura', disponible: true, capacidad: 300, ocupados: 0, horario: 'Según evento', desc: 'Espacio principal para conferencias, eventos culturales y actividades institucionales con capacidad para toda la comunidad.', ubicacion: 'Edificio Principal, Segundo Piso', img: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=600&q=80' },
  { id: 8, nombre: 'Centro Médico', tipo: 'SALUD', categoria: 'Salud', disponible: true, capacidad: 20, ocupados: 5, horario: '7:00 AM - 6:00 PM', desc: 'Servicio médico estudiantil con atención en medicina general, psicología y enfermería para toda la comunidad UNAB.', ubicacion: 'Edificio Administrativo, Planta Baja', img: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=600&q=80' }
];
```

---

## 7. VISTAS A CONSTRUIR — DETALLE COMPLETO

### 7.1 VISTA DASHBOARD (Inicio) — `vista-dashboard`

**Reemplazar el placeholder actual con el dashboard completo.**

Estructura del contenido (`dash-content`):
```
H1: "Hola, [nombre]"  — color: var(--color-acento)
P:  "Bienvenido a tu panel de control académico." — color: sublabel

[Fila de 2 columnas: 60% + 40%]
  COLUMNA IZQUIERDA: Card "Resumen de Horas Libres"
    - Título cyan: "Resumen de Horas Libres"
    - Subtítulo: "Progreso actual de tu requisito institucional."
    - Chips: "74 Completadas" (naranja) + "46 Pendientes" (gris)
    - Barra de info azul claro: "Te faltan 46 horas libres para completar tu requisito."
  
  COLUMNA DERECHA: "ACCESO RÁPIDO"
    - Card clickeable: icono pin + "Mis lugares" → showVista('vista-mis-hl')
    - Card clickeable: icono silla + "Lugares disponibles" → showVista('vista-lugares')
    - Card clickeable: icono persona + "Mi perfil" → showVista('vista-perfil')

[Sección noticias]
H2: "Noticias del Campus" + link "Ver todas →" (naranja, derecha)
Grid 3 columnas de cards noticia:
  - Imagen superior (200px height, object-fit: cover, border-radius top)
  - Badge categoría (pequeño, color según tipo)
  - Título bold
  - Descripción truncada (2 líneas, overflow hidden)
  - Tiempo (gris, pequeño)
```

**Progress ring (SVG)**: Anillo circular 120px con valor 74/120
```html
<svg width="120" height="120" viewBox="0 0 120 120">
  <circle cx="60" cy="60" r="52" fill="none" stroke="#e2e8f0" stroke-width="10"/>
  <circle cx="60" cy="60" r="52" fill="none" stroke="#f59e0b" stroke-width="10"
    stroke-dasharray="326.7" stroke-dashoffset="100"
    stroke-linecap="round" transform="rotate(-90 60 60)"/>
  <text x="60" y="55" text-anchor="middle" font-size="24" font-weight="700" fill="#1e293b">74</text>
  <text x="60" y="72" text-anchor="middle" font-size="11" fill="#64748b">DE 120 HRS</text>
</svg>
```
El `stroke-dashoffset` se calcula: `circumference * (1 - completadas/total)` = `326.7 * (1 - 74/120)` ≈ `126`

---

### 7.2 VISTA LUGARES — `vista-lugares`

**Contenido dentro de dash-content:**

```
H1: "¿Dónde puedo obtener mis HL?"  — color acento
P:  "Explora los diferentes espacios del campus..."

[Barra de búsqueda + filtros de categoría]
  - Input search: "Buscar lugar..." con icono lupa
  - Botones filtro: Todos | Deporte | Alimentación | Estudio | Cultura | Salud
    (Botón activo: bg cyan, texto blanco. Inactivo: borde gris, fondo blanco)

[Grid de cards de lugares — 3 columnas, gap 20px]
  Cada card:
  - Imagen (200px height, position relative)
  - Badge disponibilidad (absoluto, top-right): "● Disponible" verde / "● Lleno" rojo
  - Tipo (ESTUDIO / DEPORTE / etc.) — pequeño, cyan, uppercase
  - Nombre del lugar — bold, 1.2rem, cyan
  - Descripción — 3 líneas truncadas
  - Botón: Si disponible → "Registrarme →" (naranja), Si lleno → "Capacidad Máxima" (gris, disabled)
  - Click en botón disponible → STATE.lugarActual = lugar; showVista('vista-detalle-lugar')
```

**JavaScript para búsqueda y filtro:**
```javascript
let filtroCategoria = 'Todos';
let busqueda = '';

function filtrarLugares() {
  return LUGARES.filter(l => {
    const matchCategoria = filtroCategoria === 'Todos' || l.categoria === filtroCategoria;
    const matchBusqueda = l.nombre.toLowerCase().includes(busqueda.toLowerCase()) ||
                          l.categoria.toLowerCase().includes(busqueda.toLowerCase());
    return matchCategoria && matchBusqueda;
  });
}

function renderLugares() {
  const grid = document.getElementById('grid-lugares');
  const filtrados = filtrarLugares();
  grid.innerHTML = filtrados.map(l => `<!-- card HTML -->`).join('');
}
```

---

### 7.3 VISTA DETALLE LUGAR — `vista-detalle-lugar`

**Layout especial (sin sidebar — usar header+contenido full width):**

```
← Volver a Lugares (link cyan, arriba)

[Imagen hero — 400px height, full width, overlay degradado azul]
  Nombre del lugar — blanco, bold, grande (sobre imagen)
  Subtipo — blanco, opacity 75%

[Grid 2 columnas: contenido + sidebar]
  IZQUIERDA:
    H2: "Sobre este lugar" — cyan
    Párrafo descripción completa
    Normas del lugar (texto secundario)
  
  DERECHA (sticky sidebar):
    Card con:
    - 📍 UBICACIÓN: texto
    - 🕐 HORARIO DE OPERACIÓN: texto  
    - 👥 CAPACIDAD MÁXIMA: texto
    - Badge: "● Disponible para registro" (verde) / "● Lleno" (rojo)
    - Botón "Registrarme en este lugar" (naranja, full width)
      onClick → abrirModal()
    - Nota: "Recuerda que el registro es válido por bloques de 2 horas continuas."

[MODAL de confirmación — overlay oscuro + card centrada]
  Icono calendario (cyan bg, redondeado)
  H2: "Confirmar Registro"
  P: "¿Confirmas tu registro en [Lugar]? Se asignará tu espacio según la disponibilidad actual."
  Botones: [Cancelar] [Confirmar →]
  Confirmar → cerrarModal(); showVista('vista-registro-exitoso')
```

**JavaScript modal:**
```javascript
function abrirModal() {
  document.getElementById('modal-confirmar').classList.add('visible');
  document.body.style.overflow = 'hidden';
}
function cerrarModal() {
  document.getElementById('modal-confirmar').classList.remove('visible');
  document.body.style.overflow = '';
}
function confirmarRegistro() {
  cerrarModal();
  showVista('vista-registro-exitoso');
}
```

**CSS modal:**
```css
.modal-overlay {
  display: none; position: fixed; inset: 0;
  background: rgba(14,165,200,.2); backdrop-filter: blur(4px);
  z-index: 500; align-items: center; justify-content: center;
}
.modal-overlay.visible { display: flex; }
.modal-card {
  background: #fff; border-radius: 12px; padding: 40px 36px;
  max-width: 420px; width: 90%; box-shadow: 0 25px 60px rgba(0,0,0,.2);
  animation: fadeIn .25s ease;
}
```

---

### 7.4 VISTA REGISTRO EXITOSO — `vista-registro-exitoso`

**Contenido dentro de dash-content (con sidebar):**

```
[Card verde claro con ícono ✓]
  "¡Registro Exitoso!"
  "Tu espacio en [nombre lugar] ha sido reservado y confirmado."

[Imagen del lugar — full width, 280px height]
  [Nombre + subtipo sobre imagen]

[Grid 3 columnas: info del lugar]
  📍 UBICACIÓN: texto
  🕐 HORARIO: texto
  👥 CAPACIDAD: texto

[Card derecha — "Mi Registro" con borde naranja]
  ESTADO: ● Activo (verde)
  BLOQUE RESERVADO: Próximas 2 horas
  [Botón naranja]: "Ver mis registros" → showVista('vista-mis-hl')
  [Link cyan]: "Volver a Lugares" → showVista('vista-lugares')
```

---

### 7.5 VISTA MIS HL — `vista-mis-hl`

**Contenido dentro de dash-content:**

```
H1: "Mis lugares registrados"
P: "Administra tus reservas activas y revisa el historial..."

[Tabs: "Activos" (naranja subrayado) | "Historial" (gris)]

[Grid 3 columnas — Registros activos]
  Cada card:
    - Tipo (pequeño, uppercase, gris)
    - Nombre lugar (cyan, bold, 1.1rem)
    - Línea separadora
    - 📅 Fecha • Hora
    - Badge estado: "● Activo" (verde) / "● Completado" (gris)
    - Si activo: ✕ en top-right para cancelar

[Estado vacío (si no hay registros)]:
  Icono calendario con ✕
  "Aún no te has inscrito en ningún lugar"
  P descripción
  Botón "Explorar Lugares" → showVista('vista-lugares')
```

**JavaScript tabs:**
```javascript
function switchTab(tab) {
  const activos = document.getElementById('tab-activos');
  const historial = document.getElementById('tab-historial');
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('activo'));
  document.getElementById('tab-btn-' + tab).classList.add('activo');
  activos.style.display = tab === 'activos' ? 'grid' : 'none';
  historial.style.display = tab === 'historial' ? 'block' : 'none';
}
```

---

### 7.6 VISTA FAVORITOS — `vista-favoritos`

**Contenido dentro de dash-content:**

```
H1: "Lugares favoritos"
P: "Tus espacios de estudio guardados para un registro rápido."
Span derecha: "Mostrando X lugares guardados"

[Grid 3 columnas de cards]
  Cada card:
    - Imagen (180px)
    - Icono ❤️ (rojo) top-right — click para quitar de favoritos
    - Nombre (cyan, bold)
    - Badge disponibilidad + info adicional (cupos / "Libera a las XX:XX")
    - Descripción
    - Botón: "Registrarme →" si disponible, "Reservar Turno" si ocupado

[Estado vacío (si favorites = [])]
  Ícono corazón gris
  "No tienes lugares favoritos aún"
  P explicación
  Botón outline: "¡Explora el campus!" → showVista('vista-lugares')
```

---

### 7.7 VISTA PERFIL — `vista-perfil`

**Contenido dentro de dash-content:**

```
H1: "Perfil del estudiante"
P: "Gestiona tu información y revisa tu progreso académico."

[Grid 2 columnas: perfil izquierda + progreso derecha]

IZQUIERDA — Card perfil:
  Avatar/foto (100px, circular, bg gris con icono)
  Nombre: "Camilo Gómez" (cyan, bold, 1.3rem, centrado)
  Info en filas (label gris + valor):
    CÓDIGO: 000123456
    PROGRAMA: Ingeniería de Sistemas
    SEMESTRE: 7mo
  Botón outline: "✏ Editar perfil"

DERECHA — Card Resumen HL:
  H3: "Resumen de Horas Libres (HL)" — cyan
  Grid 3 stats:
    Total Requeridas: 120
    Completadas: 74 (cyan)
    Pendientes: 46 (rojo)
  Barra de progreso:
    Label: "Progreso General" + "61%" (cyan, derecha)
    Barra: fondo gris, fill cyan, width: 61%, height 8px, border-radius 4px

  Card historial:
  H3: "Historial de Lugares Completados" — cyan
  Tabla:
    Headers: FECHA | LUGAR | ACTIVIDAD | HORAS
    Filas de STATE.historialHL
    HORAS en verde: "+4", "+2", etc.
```

---

## 8. HEADER DEL DASHBOARD

El header actual (simple) debe **cambiar dinámicamente** cuando el usuario está en el dashboard:

```javascript
function setHeaderDashboard() {
  const header = document.querySelector('.site-header');
  header.innerHTML = `
    <a class="logo" onclick="showVista('vista-dashboard')">
      <span class="logo-icon"><!-- svg --></span>
      <span class="logo-text">EntreHoras</span>
    </a>
    <div style="display:flex;align-items:center;gap:16px;margin-left:auto;">
      <button class="header-icon-btn" aria-label="Buscar"><!-- svg lupa --></button>
      <div class="header-avatar" onclick="showVista('vista-perfil')"><!-- icono --></div>
    </div>
  `;
}
```

Llamar `setHeaderDashboard()` al hacer login exitoso y al navegar entre vistas de dashboard.

---

## 9. RESPONSIVE (OBLIGATORIO)

### Breakpoints:
```css
/* Tablet */
@media (max-width: 860px) {
  .dashboard-layout { grid-template-columns: 1fr; }
  .sidebar { display: none; } /* reemplazar con bottom nav */
  .dash-content { padding: 24px 20px; }
}

/* Mobile */
@media (max-width: 600px) {
  .noticias-grid { grid-template-columns: 1fr; }
  .lugares-grid { grid-template-columns: 1fr; }
  .perfil-grid { grid-template-columns: 1fr; }
}
```

### Bottom Nav (mobile — reemplaza sidebar en móvil):
```html
<nav class="bottom-nav">
  <a onclick="showVista('vista-dashboard')" class="bottom-nav-item activo"><!-- home --><span>Inicio</span></a>
  <a onclick="showVista('vista-mis-hl')" class="bottom-nav-item"><!-- reloj --><span>Mis HL</span></a>
  <a onclick="showVista('vista-lugares')" class="bottom-nav-item"><!-- pin --><span>Lugares</span></a>
  <a onclick="showVista('vista-favoritos')" class="bottom-nav-item"><!-- corazón --><span>Favoritos</span></a>
  <a onclick="showVista('vista-perfil')" class="bottom-nav-item"><!-- persona --><span>Perfil</span></a>
</nav>
```

```css
.bottom-nav {
  display: none;
  position: fixed; bottom: 0; left: 0; right: 0;
  background: #fff; border-top: 1px solid var(--color-borde);
  z-index: 200; padding: 8px 0 4px;
}
@media (max-width: 860px) { .bottom-nav { display: flex; justify-content: space-around; } }
.bottom-nav-item {
  display: flex; flex-direction: column; align-items: center;
  gap: 3px; cursor: pointer; font-size: .7rem; color: var(--color-sublabel);
  padding: 4px 12px; border-radius: 8px; transition: color .15s;
}
.bottom-nav-item.activo { color: var(--color-acento); }
.bottom-nav-item svg { width: 22px; height: 22px; }
```

---

## 10. FUNCIONALIDADES JS REQUERIDAS

| # | Función | Descripción |
|---|---|---|
| 1 | `showVista(id)` | ✅ Ya existe — NO modificar |
| 2 | `handleRegistro()` | ✅ Ya existe |
| 3 | `handleLogin()` | ✅ Ya existe — agregar llamada a `initDashboard()` |
| 4 | `initDashboard()` | Renderiza el dashboard con datos de STATE |
| 5 | `renderLugares()` | Renderiza cards con filtros aplicados |
| 6 | `filtrarLugares()` | Filtra por categoría y búsqueda |
| 7 | `setFiltro(cat)` | Cambia filtro activo y re-renderiza |
| 8 | `verDetalleLugar(id)` | Carga STATE.lugarActual y navega al detalle |
| 9 | `abrirModal()` / `cerrarModal()` | Control del modal de confirmación |
| 10 | `confirmarRegistro()` | Cierra modal, navega a registro-exitoso |
| 11 | `toggleFavorito(nombre)` | Agrega/quita de STATE.favoritos |
| 12 | `switchTab(tab)` | Cambia entre Activos/Historial en Mis HL |
| 13 | `setNavActivo(vistaId)` | Marca el ítem correcto del sidebar como activo |
| 14 | `showToast(msg, tipo)` | ✅ Ya existe |
| 15 | `togglePw(inputId, btn)` | ✅ Ya existe |

### Integración en showVista (agregar):
```javascript
function showVista(id) {
  document.querySelectorAll('.vista').forEach(v => v.classList.remove('activa'));
  const target = document.getElementById(id);
  if (target) target.classList.add('activa');
  window.scrollTo({ top: 0, behavior: 'smooth' });
  
  // Re-renderizar vistas dinámicas
  if (id === 'vista-dashboard') renderDashboard();
  if (id === 'vista-lugares') renderLugares();
  if (id === 'vista-detalle-lugar') renderDetalleLugar();
  if (id === 'vista-registro-exitoso') renderRegistroExitoso();
  if (id === 'vista-mis-hl') renderMisHL();
  if (id === 'vista-favoritos') renderFavoritos();
  if (id === 'vista-perfil') renderPerfil();
  
  // Marcar nav activo
  setNavActivo(id);
}
```

---

## 11. COMPONENTES CSS NUEVOS (agregar a styles.css)

```css
/* ── CARDS GENÉRICAS ── */
.card-stat {
  background: #fff; border: 1px solid var(--color-borde);
  border-radius: 8px; padding: 20px 24px;
  display: flex; flex-direction: column; gap: 6px;
}
.card-stat-label { font-size: .72rem; font-weight: 600; text-transform: uppercase; letter-spacing: .7px; color: var(--color-sublabel); }
.card-stat-valor { font-size: 2rem; font-weight: 700; color: var(--color-texto); }
.card-stat-valor.cyan { color: var(--color-acento); }
.card-stat-valor.rojo { color: var(--color-error); }

/* ── BADGE DISPONIBILIDAD ── */
.badge-disp {
  display: inline-flex; align-items: center; gap: 5px;
  font-size: .72rem; font-weight: 600; padding: 3px 10px;
  border-radius: 20px;
}
.badge-disp.disponible { background: rgba(34,197,94,.12); color: #16a34a; }
.badge-disp.lleno { background: rgba(239,68,68,.12); color: #dc2626; }

/* ── BADGE CATEGORÍA NOTICIA ── */
.badge-cat {
  font-size: .7rem; font-weight: 600; text-transform: uppercase;
  letter-spacing: .5px; margin-bottom: 6px; display: block;
}
.badge-cat.evento { color: #f59e0b; }
.badge-cat.academico { color: var(--color-acento); }
.badge-cat.servicio { color: #f59e0b; }

/* ── CARD NOTICIA ── */
.noticia-card {
  background: #fff; border-radius: 8px; overflow: hidden;
  border: 1px solid var(--color-borde); cursor: pointer;
  transition: box-shadow .2s, transform .15s;
}
.noticia-card:hover { box-shadow: 0 8px 24px rgba(0,0,0,.1); transform: translateY(-2px); }
.noticia-img { width: 100%; height: 180px; object-fit: cover; display: block; }
.noticia-body { padding: 16px; }
.noticia-titulo { font-size: .95rem; font-weight: 700; color: var(--color-texto); margin-bottom: 6px; line-height: 1.3; }
.noticia-desc { font-size: .82rem; color: var(--color-sublabel); line-height: 1.5; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
.noticia-tiempo { font-size: .75rem; color: #94a3b8; margin-top: 10px; display: block; }

/* ── LUGAR CARD ── */
.lugar-card {
  background: #fff; border-radius: 8px; overflow: hidden;
  border: 1px solid var(--color-borde); display: flex; flex-direction: column;
  transition: box-shadow .2s, transform .15s;
}
.lugar-card:hover { box-shadow: 0 8px 24px rgba(0,0,0,.1); transform: translateY(-2px); }
.lugar-img-wrap { position: relative; }
.lugar-img { width: 100%; height: 180px; object-fit: cover; display: block; }
.lugar-badge-disp { position: absolute; top: 10px; right: 10px; }
.lugar-body { padding: 16px; flex: 1; display: flex; flex-direction: column; }
.lugar-tipo { font-size: .68rem; font-weight: 700; text-transform: uppercase; letter-spacing: .8px; color: var(--color-acento); margin-bottom: 4px; }
.lugar-nombre { font-size: 1.1rem; font-weight: 700; color: var(--color-acento); margin-bottom: 8px; }
.lugar-desc { font-size: .82rem; color: var(--color-sublabel); line-height: 1.5; flex: 1; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; }
.lugar-card .btn-lugar { margin-top: 14px; }

/* ── BOTÓN LUGAR ── */
.btn-lugar {
  display: block; width: 100%; padding: 11px;
  font-family: var(--font-main); font-size: .88rem; font-weight: 600;
  border-radius: var(--radio); cursor: pointer; border: none;
  transition: background .2s;
}
.btn-lugar.disponible { background: var(--color-boton); color: #fff; }
.btn-lugar.disponible:hover { background: var(--color-boton-hover); }
.btn-lugar.lleno { background: #e2e8f0; color: #94a3b8; cursor: not-allowed; }

/* ── FILTROS CATEGORÍA ── */
.filtros-wrap { display: flex; gap: 8px; flex-wrap: wrap; margin: 16px 0; }
.filtro-btn {
  padding: 6px 16px; border-radius: 20px; font-size: .82rem; font-weight: 500;
  border: 1.5px solid var(--color-borde); background: #fff; color: var(--color-sublabel);
  cursor: pointer; transition: all .15s;
}
.filtro-btn:hover { border-color: var(--color-acento); color: var(--color-acento); }
.filtro-btn.activo { background: var(--color-acento); color: #fff; border-color: var(--color-acento); }

/* ── SEARCH BAR ── */
.search-bar {
  display: flex; align-items: center; gap: 10px;
  border: 1.5px solid var(--color-borde); border-radius: var(--radio);
  padding: 10px 14px; background: #fff; max-width: 360px;
  transition: border-color .2s;
}
.search-bar:focus-within { border-color: var(--color-acento); }
.search-bar input { border: none; outline: none; font-family: var(--font-main); font-size: .9rem; width: 100%; }
.search-bar svg { color: #94a3b8; flex-shrink: 0; width: 18px; height: 18px; }

/* ── REGISTRO ACTIVO CARD ── */
.registro-card {
  background: #fff; border: 1px solid var(--color-borde); border-radius: 8px;
  padding: 20px; position: relative;
}
.registro-card .reg-tipo { font-size: .68rem; font-weight: 700; text-transform: uppercase; letter-spacing: .8px; color: var(--color-sublabel); }
.registro-card .reg-nombre { font-size: 1rem; font-weight: 700; color: var(--color-acento); margin: 4px 0 12px; }
.registro-card .reg-separador { height: 1px; background: var(--color-borde); margin-bottom: 12px; }
.registro-card .reg-fecha { font-size: .82rem; color: var(--color-sublabel); display: flex; align-items: center; gap: 6px; }
.btn-cancelar-reg {
  position: absolute; top: 14px; right: 14px; background: none; border: none;
  cursor: pointer; color: #94a3b8; padding: 4px; border-radius: 50%;
  display: flex; align-items: center; transition: color .15s, background .15s;
}
.btn-cancelar-reg:hover { color: var(--color-error); background: rgba(239,68,68,.1); }

/* ── TABLA HISTORIAL ── */
.tabla-historial { width: 100%; border-collapse: collapse; }
.tabla-historial th { font-size: .68rem; font-weight: 700; text-transform: uppercase; letter-spacing: .7px; color: var(--color-sublabel); text-align: left; padding: 10px 14px; border-bottom: 2px solid var(--color-borde); }
.tabla-historial td { padding: 14px; border-bottom: 1px solid var(--color-borde); font-size: .88rem; }
.tabla-historial .horas-col { color: var(--color-exito); font-weight: 700; text-align: right; }

/* ── PROGRESS BAR ── */
.progress-bar-wrap { margin: 10px 0; }
.progress-bar-track { height: 8px; background: var(--color-borde); border-radius: 4px; overflow: hidden; }
.progress-bar-fill { height: 100%; background: var(--color-acento); border-radius: 4px; transition: width .6s ease; }
.progress-label { display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px; font-size: .85rem; font-weight: 600; }
.progress-label .pct { color: var(--color-acento); }

/* ── ACCESO RÁPIDO ── */
.acceso-rapido-item {
  display: flex; align-items: center; justify-content: space-between;
  padding: 14px 18px; border: 1px solid var(--color-borde); border-radius: 8px;
  background: #fff; cursor: pointer; transition: box-shadow .15s, border-color .15s;
  margin-bottom: 10px;
}
.acceso-rapido-item:hover { border-color: var(--color-acento); box-shadow: 0 4px 12px rgba(14,165,200,.1); }
.acceso-rapido-icon {
  width: 38px; height: 38px; border-radius: 8px; background: rgba(14,165,200,.1);
  display: flex; align-items: center; justify-content: center; flex-shrink: 0;
}
.acceso-rapido-icon svg { width: 20px; height: 20px; color: var(--color-acento); }
.acceso-rapido-texto { flex: 1; margin-left: 14px; font-weight: 600; font-size: .9rem; }

/* ── GRIDS ── */
.noticias-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-top: 16px; }
.lugares-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
.perfil-grid { display: grid; grid-template-columns: 360px 1fr; gap: 24px; }

/* ── ÉXITO BANNER ── */
.exito-banner {
  display: flex; align-items: center; gap: 14px;
  background: rgba(34,197,94,.08); border: 1px solid rgba(34,197,94,.2);
  border-radius: 8px; padding: 16px 20px; margin-bottom: 24px;
}
.exito-banner svg { width: 24px; height: 24px; color: var(--color-exito); flex-shrink: 0; }
.exito-banner h3 { font-size: 1.1rem; font-weight: 700; color: var(--color-exito); }
.exito-banner p { font-size: .85rem; color: var(--color-sublabel); }

/* ── PERFIL CARD ── */
.perfil-card { background: #fff; border: 1px solid var(--color-borde); border-radius: 8px; padding: 28px; }
.perfil-nombre { font-size: 1.2rem; font-weight: 700; color: var(--color-acento); text-align: center; margin: 12px 0 20px; }
.perfil-fila { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid var(--color-borde); font-size: .88rem; }
.perfil-fila-label { font-size: .68rem; font-weight: 700; text-transform: uppercase; letter-spacing: .7px; color: var(--color-sublabel); }
.perfil-fila-valor { font-weight: 600; color: var(--color-texto); }
.btn-editar-perfil {
  display: flex; align-items: center; justify-content: center; gap: 8px;
  width: 100%; margin-top: 20px; padding: 12px;
  border: 1.5px solid var(--color-acento); color: var(--color-acento);
  background: transparent; border-radius: var(--radio);
  font-family: var(--font-main); font-size: .9rem; font-weight: 600;
  cursor: pointer; transition: background .15s, color .15s;
}
.btn-editar-perfil:hover { background: var(--color-acento); color: #fff; }

/* ── TAB BUTTONS ── */
.tabs-wrap { display: flex; gap: 0; border-bottom: 2px solid var(--color-borde); margin-bottom: 24px; }
.tab-btn {
  padding: 10px 20px; font-family: var(--font-main); font-size: .9rem; font-weight: 500;
  border: none; background: none; cursor: pointer; color: var(--color-sublabel);
  position: relative; transition: color .15s;
}
.tab-btn.activo { color: var(--color-boton); font-weight: 700; }
.tab-btn.activo::after {
  content: ''; position: absolute; bottom: -2px; left: 0; right: 0;
  height: 2px; background: var(--color-boton);
}

/* ── HERO DETALLE LUGAR ── */
.lugar-hero {
  position: relative; height: 360px; border-radius: 8px; overflow: hidden; margin-bottom: 28px;
}
.lugar-hero img { width: 100%; height: 100%; object-fit: cover; display: block; }
.lugar-hero-overlay {
  position: absolute; inset: 0;
  background: linear-gradient(to top, rgba(10,40,80,.85) 0%, rgba(14,60,120,.3) 60%, transparent 100%);
  display: flex; flex-direction: column; justify-content: flex-end; padding: 28px 32px;
}
.lugar-hero-nombre { font-size: 2rem; font-weight: 700; color: #fff; }
.lugar-hero-subtipo { font-size: .92rem; color: rgba(255,255,255,.75); }

/* ── DETALLE GRID ── */
.detalle-grid { display: grid; grid-template-columns: 1fr 300px; gap: 24px; }
.detalle-sidebar-card { background: #fff; border: 1px solid var(--color-borde); border-radius: 8px; padding: 24px; position: sticky; top: 80px; }
.detalle-info-row { display: flex; align-items: flex-start; gap: 10px; margin-bottom: 14px; }
.detalle-info-label { font-size: .68rem; font-weight: 700; text-transform: uppercase; letter-spacing: .7px; color: var(--color-sublabel); margin-bottom: 2px; }
.detalle-info-valor { font-size: .95rem; font-weight: 700; color: var(--color-texto); }
.detalle-info-row svg { width: 18px; height: 18px; color: var(--color-acento); flex-shrink: 0; margin-top: 2px; }
.btn-volver {
  display: inline-flex; align-items: center; gap: 6px;
  font-size: .88rem; color: var(--color-acento); cursor: pointer;
  margin-bottom: 20px; font-weight: 500; background: none; border: none;
  padding: 0; transition: color .15s;
}
.btn-volver:hover { color: var(--color-header-dark); }

/* ── ESTADO VACÍO ── */
.estado-vacio {
  border: 1.5px dashed var(--color-borde); border-radius: 8px;
  padding: 48px 24px; text-align: center; background: #fff;
}
.estado-vacio-icon {
  width: 64px; height: 64px; border-radius: 12px; background: rgba(14,165,200,.08);
  margin: 0 auto 16px; display: flex; align-items: center; justify-content: center;
}
.estado-vacio-icon svg { width: 32px; height: 32px; color: var(--color-acento); opacity: .5; }
.estado-vacio h3 { font-size: 1.1rem; font-weight: 700; color: var(--color-texto); margin-bottom: 8px; }
.estado-vacio p { font-size: .88rem; color: var(--color-sublabel); max-width: 320px; margin: 0 auto 20px; }
.btn-outline {
  display: inline-flex; align-items: center; gap: 8px;
  padding: 10px 20px; border: 1.5px solid var(--color-borde); border-radius: var(--radio);
  background: #fff; font-family: var(--font-main); font-size: .88rem; font-weight: 600;
  color: var(--color-texto); cursor: pointer; transition: border-color .15s, color .15s;
}
.btn-outline:hover { border-color: var(--color-acento); color: var(--color-acento); }

/* ── CARD MI REGISTRO (exitoso) ── */
.mi-registro-card {
  border: 2px solid var(--color-boton); border-radius: 8px; padding: 24px;
  background: #fff;
}
.mi-registro-titulo { font-size: 1rem; font-weight: 700; color: var(--color-acento); margin-bottom: 16px; display: flex; align-items: center; gap: 8px; }
.mi-registro-label { font-size: .68rem; font-weight: 700; text-transform: uppercase; letter-spacing: .7px; color: var(--color-sublabel); margin-bottom: 4px; }
.mi-registro-valor { font-size: .95rem; font-weight: 600; color: var(--color-texto); margin-bottom: 14px; }
.btn-link-cyan { background: none; border: none; color: var(--color-acento); font-family: var(--font-main); font-size: .9rem; font-weight: 600; cursor: pointer; text-align: center; width: 100%; margin-top: 10px; transition: color .15s; }
.btn-link-cyan:hover { color: var(--color-header-dark); text-decoration: underline; }

/* ── INFO CARDS DETALLE (3 en fila) ── */
.info-cards-row { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 24px; }
.info-card-item { background: #fff; border: 1px solid var(--color-borde); border-radius: 8px; padding: 18px; text-align: center; }
.info-card-icon { width: 36px; height: 36px; margin: 0 auto 10px; color: var(--color-acento); }
.info-card-label { font-size: .68rem; font-weight: 700; text-transform: uppercase; letter-spacing: .7px; color: var(--color-sublabel); margin-bottom: 4px; }
.info-card-val { font-size: .95rem; font-weight: 700; color: var(--color-texto); }

/* ── NOTA INFORMATIVA ── */
.nota-info { display: flex; align-items: flex-start; gap: 8px; font-size: .8rem; color: var(--color-sublabel); margin-top: 12px; }
.nota-info svg { width: 14px; height: 14px; flex-shrink: 0; margin-top: 1px; }
```

---

## 12. ÍCONOS SVG UTILIZADOS

Todos los íconos son SVG inline (Lucide style). Usar siempre:
- `fill="none"`, `stroke="currentColor"`, `stroke-width="2"`, `stroke-linecap="round"`, `stroke-linejoin="round"`
- Tamaño estándar: `width="18" height="18"` (ajustar según contexto)

```html
<!-- Home -->
<svg viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>

<!-- Reloj (Mis HL) -->
<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>

<!-- Pin (Lugares) -->
<svg viewBox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>

<!-- Corazón (Favoritos) -->
<svg viewBox="0 0 24 24"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>

<!-- Persona (Perfil) -->
<svg viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>

<!-- Lupa -->
<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>

<!-- Pin mapa small -->
<svg viewBox="0 0 24 24"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z"/><circle cx="12" cy="9" r="2.5"/></svg>

<!-- Reloj pequeño -->
<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>

<!-- Personas -->
<svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>

<!-- Check círculo -->
<svg viewBox="0 0 24 24"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>

<!-- Calendario -->
<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>

<!-- Calendario X -->
<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/><line x1="10" y1="14" x2="14" y2="18"/><line x1="14" y1="14" x2="10" y2="18"/></svg>

<!-- Lápiz -->
<svg viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>

<!-- Flecha derecha -->
<svg viewBox="0 0 24 24"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>

<!-- X (cerrar) -->
<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>

<!-- Deporte (pesas) -->
<svg viewBox="0 0 24 24"><path d="M6 4v16M18 4v16M6 12h12M3 8h3M3 16h3M18 8h3M18 16h3"/></svg>

<!-- Tenedor (alimentación) -->
<svg viewBox="0 0 24 24"><path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2"/><path d="M7 2v20M21 15V2a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3zm0 0v7"/></svg>

<!-- Libro (estudio) -->
<svg viewBox="0 0 24 24"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>

<!-- Música (cultura) -->
<svg viewBox="0 0 24 24"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>

<!-- Cruz (salud) -->
<svg viewBox="0 0 24 24"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78"/><path d="M9 12h6M12 9v6"/></svg>
```

---

## 13. CHECKLIST DE CALIDAD FINAL

Antes de dar por completado, verificar:

- [ ] `vista-registro` → formulario funciona con validaciones
- [ ] `vista-login` → login dirige al dashboard, toast de bienvenida
- [ ] `vista-dashboard` → progress ring, noticias, acceso rápido
- [ ] `vista-lugares` → búsqueda en tiempo real, filtros de categoría funcionan
- [ ] `vista-detalle-lugar` → carga datos del lugar seleccionado, modal funciona
- [ ] `vista-registro-exitoso` → muestra datos del lugar registrado
- [ ] `vista-mis-hl` → tabs activos/historial funcionan
- [ ] `vista-favoritos` → toggle de favorito funciona, estado vacío
- [ ] `vista-perfil` → tabla historial, barra de progreso
- [ ] Sidebar resalta nav-item activo en cada vista
- [ ] Header cambia a versión dashboard al entrar al dashboard
- [ ] Toast funciona en toda la app
- [ ] Responsive: sidebar colapsa en móvil, bottom nav aparece
- [ ] No hay errores en consola del navegador
- [ ] Animación fadeIn al cambiar de vista
- [ ] Colores respetan el sistema de variables CSS
- [ ] Todo funciona sin servidor (abrir index.html directamente en navegador)

---

## 14. NOTAS CRÍTICAS PARA OPENCODE

1. **NO usar localStorage ni sessionStorage** — todos los datos en el objeto `STATE` en memoria.
2. **NO usar frameworks** — HTML/CSS/JS vanilla únicamente.
3. **NO fragmentar en múltiples archivos** — todo en `index.html`, `styles.css`, `script.js`.
4. **Respetar los IDs** — el sistema de navegación depende de los IDs exactos de las vistas.
5. **Imágenes** — usar URLs de Unsplash con parámetros `?w=600&q=80` para performance.
6. **El sidebar debe ser reutilizable** — generarlo con una función `renderSidebar(vistaActiva)` e inyectarlo en cada vista dashboard, o mejor, tenerlo como HTML estático dentro de cada sección.
7. **La vista `vista-detalle-lugar` tiene su propio layout** (sin sidebar fijo) — usa el header de navegación horizontal como en el PDF diseño página 6.
8. **Funciona abriendo `index.html` directamente** en el navegador sin servidor.
