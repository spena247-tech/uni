# Pagina Web Sofi

Date Created: 14 de mayo de 2026 21:14
Status: In progress

# **Plan: Ajustes Visuales y Perfil de EntreHoras UNAB**

## **Resumen**

Actualizar la identidad visual con el nuevo logo, compactar el registro, fijar los datos del estudiante desde el registro/login, mejorar Mis HL y suavizar las transiciones entre vistas. Se mantiene HTML/CSS/JS vanilla, sin backend ni dependencias.

Fuente del nuevo logo revisada: https://ibb.co/yB8R357P; imagen directa detectada: https://i.ibb.co/0VfXwZv2/Gemini-Generated-Image-ig0eznig0eznig0e.png.

## **Cambios Clave**

- Cambiar CONFIG.logoUrl, header y login para usar el nuevo logo naranja.
- Ajustar la marca “EntreHoras” para combinar con el logo:
    - Usar acento naranja como color principal de marca.
    - Mantener cyan UNAB como color secundario en navegación/estados.
    - Quitar el fondo blanco tipo cápsula del logo si visualmente estorba.
- Compactar la vista de registro:
    - Reducir padding, gaps y altura mínima del card.
    - Agregar campo Semestre al formulario de registro.
    - Hacer que el formulario completo quepa mejor en laptop sin scroll excesivo.
- Cambiar usuario demo inicial a Cielo Castellanos.
- Al registrar cuenta, guardar también semestre en STATE.usuario.
- Corregir textos visibles con caracteres raros o escapes innecesarios donde afecten la UI.

## **Perfil**

- El perfil dejará de permitir editar nombre, código, correo, programa y semestre.
- El botón “Editar perfil” se reemplazará por una acción clara de foto, por ejemplo Cambiar foto.
- Agregar STATE.usuario.fotoPerfil.
- La foto de perfil será editable con un input type="file":
    - Se previsualiza en sidebar, header y perfil.
    - Se guarda solo en memoria durante la sesión.
    - Si no hay foto, se mantiene el avatar SVG actual.
- El modal actual de edición de perfil se reemplazará o simplificará para manejar solo cambio de foto.

## **Mis HL y Animaciones**

- Rediseñar las cards de reservas en Mis HL para que no usen una imagen grande tipo calendario/hero.
- Nueva card propuesta:
    - Imagen pequeña o miniatura lateral, no dominante.
    - Información principal: lugar, tipo, fecha, hora y estado.
    - Botón de cancelar discreto en reservas activas.
    - Historial y activos comparten el mismo estilo compacto.
- Mejorar transición entre secciones:
    - Reemplazar el fadeIn básico por una animación más fluida con opacidad, desplazamiento corto y escala mínima.
    - Añadir transición suave a .dash-content, cards y estados activos.
    - Respetar prefers-reduced-motion desactivando animaciones para usuarios que lo prefieran.

## **Plan de Pruebas**

- Ejecutar node --check script.js.
- Probar manualmente:
    - Registro con semestre vacío y válido.
    - Login demo y entrada al dashboard con Cielo Castellanos.
    - Perfil mostrando datos fijos.
    - Cambio de foto de perfil y reflejo en sidebar/header/perfil.
    - Mis HL activos e historial con cards compactas.
    - Favoritos, lugares, reserva exitosa y horario siguen funcionando.
    - Transiciones entre todas las secciones.
- Revisar responsive en desktop, tablet y mobile, especialmente registro, perfil, Mis HL y bottom nav.

## **Supuestos**

- Se usará el logo remoto directo de ImgBB para no agregar archivos nuevos.
- La foto de perfil no persistirá al recargar porque el proyecto sigue sin backend ni localStorage.
- El perfil queda bloqueado para datos académicos; solo la foto será editable.